-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: final
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.28-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `content` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `username` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `comments_ibfk_1` (`post_id`),
  KEY `comments_ibfk_2` (`user_id`),
  CONSTRAINT `comments_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`),
  CONSTRAINT `comments_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_pri_key`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
INSERT INTO `comments` VALUES (1,12,3,'123','2023-11-26 15:10:38',''),(2,12,3,'3214','2023-11-26 15:17:13','1'),(3,12,3,'321','2023-11-26 15:19:00','1'),(4,12,3,'41414','2023-11-26 15:19:02','1'),(5,12,3,'1231','2023-11-26 15:19:04','1'),(6,20,3,'231','2023-11-28 15:47:09','1'),(7,20,3,'324','2023-11-28 15:49:15','1');
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `images`
--

DROP TABLE IF EXISTS `images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `image_path` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `images`
--

LOCK TABLES `images` WRITE;
/*!40000 ALTER TABLE `images` DISABLE KEYS */;
/*!40000 ALTER TABLE `images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `user_pri_key` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts`
--

LOCK TABLES `posts` WRITE;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
INSERT INTO `posts` VALUES (12,'3','1','1','2023-11-26 14:52:58',3),(16,'3','5','5','2023-11-26 14:53:07',3),(17,'1','213','41231','2023-11-26 15:39:50',3),(20,'1','수정됨','수정됨','2023-11-26 15:40:02',3),(21,'1','글쓰기 test','test','2023-11-28 16:06:36',3),(22,'대환아장기해야지','대환아','장기해야지','2023-11-29 07:07:25',6),(23,'hiwon0','대환공주님','대환공듀님 숙제하러 갑시당~~ ^0^','2023-11-29 07:15:52',7),(24,'당직사관','훅훅 병장 김대환','행정반으로','2023-11-29 08:29:24',8),(25,'김대환','현재시각','현재시각 17:05\r\n','2023-12-03 08:05:35',9),(26,'김대환','오리온 포카칩 오리지널 66g 12개','10,920원','2023-12-04 16:31:54',9),(27,'김대환','올반 볶음밥 3종 220g 10개','13,980','2023-12-04 16:32:26',9),(28,'김대환','천연펄프 숨 프리미엄 블랙 3겹 30m 30롤','17,780원','2023-12-04 16:32:48',9),(29,'김대환','켈로그 코코팝스 460g 2개','5,250원','2023-12-04 16:34:29',9),(30,'김대환','포항 구룡포 손질 과메기','22,900₩','2023-12-04 16:35:03',9),(31,'김대환','mx master 3 se, mx keys se','69,000₩','2023-12-04 16:35:17',9),(32,'김대환','아이뮤즈 11인치 LTE 안드로이드 태블릿 pc','196,020₩','2023-12-04 16:35:34',9),(33,'김대환','인생닭 닭가슴살 골라담기','1,330₩','2023-12-04 16:35:50',9),(34,'김대환','유니버스 클럽 회원대상 쇼핑지원금 연말선물','0₩','2023-12-04 16:36:03',9),(35,'김대환','경북 햇 꿀 부사 사과 2kg','9,400₩','2023-12-04 16:36:15',9),(36,'김대환','맘으로 소갈비탕 600g/돼지국밥/순대국/삼계탕 외 국탕찌개 BEST 모음','3,690₩','2023-12-04 16:36:50',9),(37,'김대환','뿌셔뿌셔 떡볶이맛/양념치킨맛/바베큐맛/불고기맛 4종 24개','13,440₩','2023-12-04 16:37:13',9),(38,'김대환','버즈2프로','117,000₩','2023-12-04 16:37:23',9),(39,'김대환','통 순살 가자미 생선까스 650g+650g','28,900₩','2023-12-04 16:37:47',9),(40,'김대환','COLORFUL 지포스 RTX 4060 토마호크 DUO D6 8GB','367,000₩','2023-12-04 16:38:10',9),(41,'김대환','제나벨 PDRN 크림 70ml','26,010₩','2023-12-04 16:38:28',9),(42,'김대환','장순필 가마솥 육개장 600g 5봉','13,410₩','2023-12-04 16:38:50',9),(43,'김대환','로지텍 mx keys mini','88,000₩','2023-12-04 16:39:02',9),(44,'김대환','메가박스 2인 이용권 (티켓 2장 + 팝콘 L + 음료 R 2잔)','22,500₩','2023-12-04 16:39:26',9),(45,'김대환','[에잇세컨즈] - 남녀 니트/패팅/시즌잡화외','9,410₩','2023-12-04 16:39:54',9),(46,'김대환','아이즈모바일 요금제 할인','0₩','2023-12-04 16:41:50',9);
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `user_pri_key` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  PRIMARY KEY (`user_pri_key`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (3,'1','1','kola0709@naver.com'),(5,'2','2','kim@gmail.com'),(6,'대환아장기해야지','880526','nacht0526@hanmail.net'),(7,'hiwon0','hiwon00','hiwon0@naver.com'),(8,'당직사관','00','se0717@naver.com'),(9,'김대환','123','kola0709@naver.com');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-05  1:47:43
